﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http;
using Newtonsoft.Json;

namespace Weather_Demo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to my gangster as weather app!");
            Console.WriteLine("Which city would you like to find the weather for?");
            
            // Reads whatever the user types into console and assigns it string 'city'.
            string city = Console.ReadLine();
            
            // Calls the method 'getWeather' and passes it the string 'city'.
            getWeather(city);
            
            // This line pervents app from closing.
            Console.ReadKey();
        }

        // This method must have the 'async' tag for our HTTPClient to work when calling
        // the weather API. This is because the method used to call our API is done asynchronously,
        // requiring the 'getWeather' method to wait for our HTTPClient to finish pulling the data
        // before continuing with the rest of the code.
        static async void getWeather(string city)
        {
            // Let the user know something is happening so that they don't think the
            // app has frozen.
            Console.WriteLine("Loading weather data...");

            // We need a try/catch wrapped around our API resquest just incase an error occurs
            // while calling the weather API. If an error does occur the code inside the catch
            // statement is called, otherwise the app skips it and continues with the code.
            // Without a try/catch, if an error does occur the app would not know how to handle it
            // resulting in the app crashing. A try/catch prevents the app from crashing and can be
            // used to inform the user what went wrong.
            try
            {
                // Initializing HTTPClient.
                HttpClient client = new HttpClient();

                // Creating a new Weather Object to bind the results from our API call.
                Weather_Object.RootObject rootObject;

                // Calling our weather API, passing the string 'city' so we're getting the correct weather returned.
                // The 'await' tag tells the computer to wait for the results to be returned before continuing with
                // the rest of the code. The results are then assigned to string 'x' to be used later in the code.
                string x = await client.GetStringAsync(new Uri("http://api.openweathermap.org/data/2.5/weather?q="+ city +"&units=metric&APPID=440e3d0ee33a977c5e2fff6bc12448ee"));
                
                // We're now binding the returned data assigned to string 'x' to the object 'rootObject'.
                rootObject = JsonConvert.DeserializeObject<Weather_Object.RootObject>(x);

                // Printing the results to console for the users to see.
                Console.WriteLine(rootObject.name + "\t\t" + rootObject.main.temp + "°C");
                Console.WriteLine("Wind Speed: \t\t" + rootObject.wind.speed + "m/s");
                Console.WriteLine("Pressure: \t\t" + rootObject.main.pressure + "hPa");
                Console.WriteLine("Humidity: \t\t" + rootObject.main.humidity + "%");
                Console.WriteLine("\t" + rootObject.weather[0].description);
            }
            // Only called if an error occurs.
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.WriteLine("Press any key to exit.");
        }
    }
}
