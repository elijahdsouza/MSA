﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Web.Http;
using Windows.Devices.Geolocation;
using System.Diagnostics;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace MSA_Weather
{
    
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        // Global variable to store the current units selection
        string units;
	
        public MainPage()
        {
            this.InitializeComponent();
        }

        // Runs when MainPage is active in the frame
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
			// Load unit system from Settings page
            if (e.Parameter == null)
                units = "metric";
            else
                units = e.Parameter.ToString();
            
            base.OnNavigatedTo(e);
        }

        private void goButton_Click(object sender, RoutedEventArgs e)
        {
            string city = weatherInput.Text.ToString();
            executeWeather(city);
        }

        private async void executeWeather(string city)
        {
            // Let the user know something is happening so that they don't think the
            progressBar.Visibility = Visibility.Visible;

            // Creating a new Weather Object to bind the results from our API call.
            Weather_Object.RootObject rootObject =  await getWeather(city);

            if(rootObject.main != null)
            {
                progressBar.Visibility = Visibility.Collapsed;
                UpdateTextBlock(rootObject);
                UpdateStackPanel(rootObject);
            }
            else
            {
                progressBar.Visibility = Visibility.Collapsed;
                MessageDialog msgDialog = new MessageDialog("Enter a proper city!", "Oops!");
                await msgDialog.ShowAsync();
               
            }
        }

        // Method overload for geolocation inputs
        private async void executeWeather(string lat, string lng, string units)
        {
            // Let the user know something is happening so that they don't think the
            progressBar.Visibility = Visibility.Visible;

            // Creating a new Weather Object to bind the results from our API call.
            Weather_Object.RootObject rootObject = await getWeather(lat, lng, units);

            if (rootObject.main != null)
            {
                progressBar.Visibility = Visibility.Collapsed;
                UpdateTextBlock(rootObject);
                UpdateStackPanel(rootObject);
            }
            else
            {
                progressBar.Visibility = Visibility.Collapsed;
                MessageDialog msgDialog = new MessageDialog("Cannot get current location", "Oops!");
                await msgDialog.ShowAsync();	
            }
        }


        private void UpdateTextBlock(Weather_Object.RootObject rootObject)
        {
			// Display correct units
			string unit = " °C";
			if(units == "Imperial")
				unit = " °F";
		
            string outputString = "";
            outputString += rootObject.name + " " + rootObject.main.temp + unit + "\n";
            outputString += "Wind Speed: " + rootObject.wind.speed + " m/s" + "\n";
            outputString += "Pressure: " + rootObject.main.pressure + " hPa" + "\n";
            outputString += "Humidity: " + rootObject.main.humidity + " %" + "\n";
            outputString += rootObject.weather[0].description;

            outputBox.Text = outputString;
        }


        // What mistake have I done here?
        // HINT: It wont impact the runtime in any way, but professional devs don't like this....
        private void UpdateStackPanel(Weather_Object.RootObject rootObject)
        {
			// Display correct units
			string unit = " °C";
			if(units == "Imperial")
				unit = " °F";

            textCity.Text = rootObject.name;
            textTemp.Text = rootObject.main.temp + unit + "\n";
            textPressure.Text = "Pressure: " + rootObject.main.pressure + " hPa" + "\n";
            textHumidity.Text = "Humidity: " + rootObject.main.humidity + " %" + "\n";
            textWindDir.Text = "Wind Speed: " + rootObject.wind.speed + " m/s" + "\n";
            textDescription.Text = rootObject.weather[0].description;
            
        }



        // This method must have the 'async' tag for our HTTPClient to work when calling
        // the weather API. This is because the method used to call our API is done asynchronously,
        // requiring the 'getWeather' method to wait for our HTTPClient to finish pulling the data
        // before continuing with the rest of the code.
        private async Task<Weather_Object.RootObject> getWeather(string city)
        {


            // We need a try/catch wrapped around our API resquest just incase an error occurs
            // while calling the weather API. If an error does occur the code inside the catch
            // statement is called, otherwise the app skips it and continues with the code.
            // Without a try/catch, if an error does occur the app would not know how to handle it
            // resulting in the app crashing. A try/catch prevents the app from crashing and can be
            // used to inform the user what went wrong.
            try
            {
                // Initializing HTTPClient.
                HttpClient client = new HttpClient();

                // Creating a new Weather Object to bind the results from our API call.
                Weather_Object.RootObject rootObject;

                // Calling our weather API, passing the string 'city' so we're getting the correct weather returned.
                // The 'await' tag tells the computer to wait for the results to be returned before continuing with
                // the rest of the code. The results are then assigned to string 'x' to be used later in the code.
                string x = await client.GetStringAsync(new Uri("http://api.openweathermap.org/data/2.5/weather?q=" + city + "&units=" + units + "&APPID=440e3d0ee33a977c5e2fff6bc12448ee"));

                // We're now binding the returned data assigned to string 'x' to the object 'rootObject'.
                rootObject = JsonConvert.DeserializeObject<Weather_Object.RootObject>(x);
                return rootObject;
           
            }
            // Only called if an error occurs.
            catch (Exception ex)
            {
                return null;
            }

        }
		
		// getWeather Method overloaded for geolocation data
		private async Task<Weather_Object.RootObject> getWeather(string lat, string lng, string units)
        {
            try
            {
                // Initializing HTTPClient.
                HttpClient client = new HttpClient();

                // Creating a new Weather Object to bind the results from our API call.
                Weather_Object.RootObject rootObject;

                // Calling our weather API, passing the geolocation data so we're getting the correct weather returned.
                // The 'await' tag tells the computer to wait for the results to be returned before continuing with
                // the rest of the code. The results are then assigned to string 'x' to be used later in the code.
                string x = await client.GetStringAsync(new Uri("http://api.openweathermap.org/data/2.5/weather?lat=" 
                    + lat + "&lon=" + lng + "&units=" + units + "&APPID=440e3d0ee33a977c5e2fff6bc12448ee"));

                // We're now binding the returned data assigned to string 'x' to the object 'rootObject'.
                rootObject = JsonConvert.DeserializeObject<Weather_Object.RootObject>(x);
                return rootObject;

            }
            catch (Exception ex)
            {
                return null;
            }

        }

        // Click event for Current Location app bar button
        private async void currentLocation_Click(object sender, RoutedEventArgs e)
        {
			// Try catch to prevent app crash on failing to get location
            try
            {
				// Create new instance of Geolocator and define accuracy
                Geolocator geolocator = new Geolocator();
                geolocator.DesiredAccuracyInMeters = 100;

				// Get the Geoposition asynchronously
                Geoposition geoposition = await geolocator.GetGeopositionAsync(
					// Define maximumAge to make sure data is not too old
                    maximumAge: TimeSpan.FromMinutes(5),
					// Define timeout to prevent wastage of CPU cycles and battery
                    timeout: TimeSpan.FromSeconds(10)
                    );

				// Get latitude and longitude values (2 dp) as strings
                string lat = geoposition.Coordinate.Point.Position.Latitude.ToString("0.00");
                string lng = geoposition.Coordinate.Point.Position.Longitude.ToString("0.00");
				
				// Pass geolocation data to overloaded executeWeather method
                executeWeather(lat, lng, units);
            }
            catch(Exception ex)
            {
				// Catch errors
                Debug.WriteLine(ex.Message);
            }
        }

        
        private void settings_Click(object sender, RoutedEventArgs e)
        {
			// Navigate to the settings page
            this.Frame.Navigate(typeof(Settings));
        }

    }
}
